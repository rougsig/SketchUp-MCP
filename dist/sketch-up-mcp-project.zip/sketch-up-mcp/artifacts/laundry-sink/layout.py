import json
VARIANTS={'closed':{'name':'01 — Закрытая тумба','open':False},'open':{'name':'02 — Дверцы открыты / сифон','open':True}}
assert VARIANT in VARIANTS
GROUP_NAMES={'Frame':'Тумба — панели 18 мм','Countertop':'Столешница 30 мм','Bowl':'Чаша 500×400×250 мм',
 'Faucet':'Смеситель — условный габарит','Plumbing':'Слив и сифон — условная схема',
 'LeftDoor':'Левая дверца','RightDoor':'Правая дверца','Zones':'Резерв подключений','Access':'Открывание и доступ'}
assembly.remove(gaps);assembly.remove(access)
machine.set('name',GROUP_NAMES['Frame'])
nodes={'Frame':machine}
for key,name in GROUP_NAMES.items():
 if key not in nodes:nodes[key]=el(assembly,'node',{'id':key,'name':name})
DOORS=[{'group':'LeftDoor','hinge_mm':[3,0,143],'angle_degrees':-100},
       {'group':'RightDoor','hinge_mm':[747,0,143],'angle_degrees':100}]

def transform(vertices,group):
 if not VARIANTS[VARIANT]['open'] or group not in ('LeftDoor','RightDoor'):return vertices
 door=next(d for d in DOORS if d['group']==group);hx,hy,_=door['hinge_mm'];a=math.radians(door['angle_degrees'])
 return [(hx+(x-hx)*math.cos(a)-(y-hy)*math.sin(a),hy+(x-hx)*math.sin(a)+(y-hy)*math.cos(a),z) for x,y,z in vertices]

def part(name,origin,size,group='Frame',material='yellow'):
 box(name,*origin,*size,nodes[group],material);primitives[-1]['group']=group
 name,v,f,m,b=records[-1];records[-1]=(name,transform(v,group),f,m,b)
 if group in ('LeftDoor','RightDoor') and VARIANTS[VARIANT]['open']:
  door=next(d for d in DOORS if d['group']==group);hx,hy,_=door['hinge_mm'];a=math.radians(door['angle_degrees']);c=math.cos(a);s=math.sin(a)
  geomnode=list(nodes[group])[-1]
  el(geomnode,'matrix',text=f'{c} {s} 0 0 {-s} {c} 0 0 0 0 1 0 {hx-c*hx+s*hy} {hy-s*hx-c*hy} 0 1')

def plane(name,vertices,group='Zones'):
 mesh(name,vertices,[(0,1,2,3)],nodes[group],'red')
 primitives.append({'type':'rectangle','name':name,'vertices':vertices,'group':group,'material':'red'})

def tube(name,center,axis,radius,length,inner=0,group='Plumbing',material='ochre'):
 # Preview mesh only; native importer uses add_circle and pushpull.
 n=48; u,v={'Z':((1,0,0),(0,1,0)),'Y':((1,0,0),(0,0,-1)),'X':((0,1,0),(0,0,1))}[axis]
 normal={'X':(1,0,0),'Y':(0,1,0),'Z':(0,0,1)}[axis]
 rings=[(radius,0),(radius,length)]+([(inner,length),(inner,0)] if inner else [])
 vertices=[tuple(center[j]+normal[j]*height+r*(u[j]*math.cos(i*2*math.pi/n)+v[j]*math.sin(i*2*math.pi/n)) for j in range(3)) for r,height in rings for i in range(n)]
 faces=[(i,(i+1)%n,n+(i+1)%n,n+i) for i in range(n)]
 if inner:faces += [(k*n+i,k*n+(i+1)%n,((k+1)%4)*n+(i+1)%n,((k+1)%4)*n+i) for k in (1,2,3) for i in range(n)]
 else:faces += [tuple(range(n-1,-1,-1)),tuple(range(n,2*n))]
 mesh(name,vertices,faces,nodes[group],material)
 primitives.append({'type':'tube','name':name,'center':center,'axis':axis,'radius':radius,'inner':inner,'length':length,'group':group,'material':material})

part('Левая боковина',[0,18,140],[18,702,780])
part('Правая боковина',[732,18,140],[18,702,780])
part('Дно тумбы',[18,18,140],[714,652,18])
part('Цоколь — утоплен 60 мм',[18,60,0],[714,18,140])
for y in (18,670):part('Верхняя поперечина',[18,y,870],[714,50,50])
part('Задняя нижняя поперечина',[18,670,158],[714,18,70])
for group,x,w in [('LeftDoor',3,370.5),('RightDoor',376.5,370.5)]:
 part(GROUP_NAMES[group]+' — фасад',[x,0,143],[w,18,774],group)
 handle_x=338 if group=='LeftDoor' else 400
 part(GROUP_NAMES[group]+' — ручка',[handle_x,-12,770],[12,12,110],group,'ochre')
 for z in (250,760):part('Условная петля',[18 if group=='LeftDoor' else 716,18,z],[16,25,30],material='ochre')

# Countertop has a true opening; no solid box across the bowl.
for name,o,s in [('Передняя полоса',[0,0,920],[750,76,30]),('Задняя площадка',[0,484,920],[750,236,30]),
                 ('Левая полоса',[0,76,920],[121,408,30]),('Правая полоса',[629,76,920],[121,408,30])]:
 part('Столешница — '+name,o,s,'Countertop')
for name,o,s in [('Левая стенка',[121,76,695],[4,408,255]),('Правая стенка',[625,76,695],[4,408,255]),
                 ('Передняя стенка',[125,76,695],[500,4,255]),('Задняя стенка',[125,480,695],[500,4,255])]:
 part('Чаша — '+name,o,s,'Bowl','sink')

# Bowl floor with a circular drain aperture. Extra rays include all rectangle corners.
cx,cy=375,360
angles=sorted(set([i*2*math.pi/48 for i in range(48)]+[math.atan2(y-cy,x-cx)%(2*math.pi) for x,y in ((125,80),(625,80),(625,480),(125,480))]))
outer=[];inside=[]
for a in angles:
 dx,dy=math.cos(a),math.sin(a)
 distances=[(bound-cx)/dx for bound in (125,625) if abs(dx)>1e-9]+[(bound-cy)/dy for bound in (80,480) if abs(dy)>1e-9]
 t=min(k for k in distances if k>1e-8)
 outer.append((cx+t*dx,cy+t*dy));inside.append((cx+25*dx,cy+25*dy))
n=len(angles);verts=[(x,y,z) for xy,z in ((outer,695),(outer,700),(inside,700),(inside,695)) for x,y in xy]
faces=[(k*n+i,k*n+(i+1)%n,((k+1)%4)*n+(i+1)%n,((k+1)%4)*n+i) for k in range(4) for i in range(n)]
mesh('Чаша — дно со сливным отверстием Ø50',verts,faces,nodes['Bowl'],'sink')
primitives.append({'type':'plate_hole','name':'Чаша — дно со сливным отверстием Ø50','origin':[125,80,695],'size':[500,400,5],'hole_center':[375,360,695],'radius':25,'group':'Bowl','material':'sink'})
tube('Слив — кольцо Ø90',[375,360,700],'Z',45,3,25,'Bowl')
tube('Слив — вертикальная труба Ø50',[375,360,630],'Z',25,70,23)
tube('Сифон — колба Ø90',[375,360,500],'Z',45,140,material='highlight')
tube('Сифон — разборная нижняя крышка',[375,360,488],'Z',48,12)
tube('Сифон — отвод к стене Ø50',[375,360,555],'Y',25,310,23)
tube('Смеситель — основание',[375,560,950],'Z',28,10,group='Faucet')
tube('Смеситель — стойка',[375,560,960],'Z',14,260,group='Faucet',material='highlight')
tube('Смеситель — поворотный излив',[375,350,1220],'Y',14,210,group='Faucet',material='highlight')
tube('Смеситель — съёмная лейка',[375,350,1180],'Z',20,40,group='Faucet')
part('Смеситель — рычаг',[393,555,985],[65,10,10],'Faucet','ochre')
plane('Резерв подключений у стены — 100 мм глубины',[[275,700,450],[475,700,450],[475,700,850],[275,700,850]])
plane('Граница сервисного места за дном — 50 мм',[[18,670,158],[732,670,158],[732,670,500],[18,670,500]])
plane('Зона доступа 600 мм',[[0,-600,0],[750,-600,0],[750,0,0],[0,0,0]],'Access')

el(el(root,'scene'),'instance_visual_scene',{'url':'#Scene'});E.indent(root)
E.ElementTree(root).write((OUTPUT_DIR / ('laundry-sink-'+VARIANT+'.dae')),encoding='utf-8',xml_declaration=True)
if VARIANT=='closed':
 (OUTPUT_DIR / ('model-primitives.json')).write_text(json.dumps({'materials':COLORS,'groups':GROUP_NAMES,'shapes':primitives,
 'zone_opacity':0.18,'body_dimensions_mm':[750,720,950],'bowl_internal_mm':[500,400,250],
 'front_bowl_offset_mm':80,'tap_top_mm':1234,'panel_thickness_mm':18,'doors':DOORS,'variants':VARIANTS,
 'row_widths_mm':[750,300,676],'row_total_mm':1726,'available_width_mm':1750,'remaining_width_mm':24,
 'note':'Условная мойка без выбранного артикула. Смеситель и сифон — габаритные схемы; место подключения уточняется.'},ensure_ascii=False,indent=2))
print('Exported',VARIANT,'750×720×950 mm; bowl inside 500×400×250 mm')
