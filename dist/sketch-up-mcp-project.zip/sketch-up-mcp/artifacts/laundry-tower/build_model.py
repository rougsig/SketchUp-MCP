from pathlib import Path

OUTPUT_DIR = Path(__file__).resolve().parent / 'cache'
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
import math
import xml.etree.ElementTree as E

NS = 'http://www.collada.org/2005/11/COLLADASchema'
E.register_namespace('', NS)
def el(parent, tag, attrs=None, text=None):
    node = E.SubElement(parent, '{'+NS+'}'+tag, attrs or {})
    if text is not None: node.text = str(text)
    return node

root = E.Element('{'+NS+'}COLLADA', {'version':'1.4.1'})
asset = el(root, 'asset')
el(asset, 'created', text='2026-10-11T00:00:00Z')
el(asset, 'modified', text='2026-10-11T00:00:00Z')
el(asset, 'unit', {'name':'millimeter', 'meter':'0.001'})
el(asset, 'up_axis', text='Z_UP')
effects = el(root, 'library_effects')
materials = el(root, 'library_materials')
COLORS = {'yellow': (254,227,0), 'ochre': (137,112,9), 'glass': (54,58,31), 'highlight': (229,219,145), 'red': (154,10,5)}
for name, rgb in COLORS.items():
    color = ' '.join(str(c/255) for c in rgb) + ' 1'
    effect = el(effects, 'effect', {'id':name+'-fx'})
    shading = el(el(el(effect,'profile_COMMON'),'technique',{'sid':'common'}),'lambert')
    el(el(shading,'diffuse'),'color',text=color)
    if name == 'red':
        el(el(shading,'transparent',{'opaque':'A_ONE'}),'color',text='1 1 1 0.18')
        el(el(shading,'transparency'),'float',text='1')
    material = el(materials,'material',{'id':name,'name':{'yellow':'My Yellow','red':'WM — Красные зоны'}.get(name,name)})
    el(material,'instance_effect',{'url':'#'+name+'-fx'})
geometries = el(root,'library_geometries')
scene = el(el(root,'library_visual_scenes'),'visual_scene',{'id':'Scene','name':'Laundry tower'})
assembly = el(scene,'node',{'id':'Assembly','name':'Пустая стойка с нижним ящиком и верхним шкафом'})
machine = el(assembly,'node',{'id':'Machine','name':'Стиральная машина 600x600x850 мм'})
gaps = el(assembly,'node',{'id':'Clearances','name':'Зазоры: сзади 100 мм, сбоку 20 мм'})
access = el(assembly,'node',{'id':'Service','name':'Условный доступ спереди 600 мм — отдельно от установочного габарита'})
counter = 0
records = []
primitives = []

def mesh(name, vertices, faces, parent=machine, material='yellow'):
    global counter
    counter += 1
    records.append((name, vertices, faces, material, parent is machine))
    ident = 'mesh'+str(counter)
    geometry = el(geometries,'geometry',{'id':ident,'name':name})
    data = el(geometry,'mesh')
    source = el(data,'source',{'id':ident+'-pos'})
    el(source,'float_array',{'id':ident+'-arr','count':str(len(vertices)*3)},' '.join(f'{n:.6f}' for v in vertices for n in v))
    acc = el(el(source,'technique_common'),'accessor',{'source':'#'+ident+'-arr','count':str(len(vertices)),'stride':'3'})
    for axis in 'XYZ': el(acc,'param',{'name':axis,'type':'float'})
    verts = el(data,'vertices',{'id':ident+'-verts'})
    el(verts,'input',{'semantic':'POSITION','source':'#'+ident+'-pos'})
    tris = [(face[0],face[i],face[i+1]) for face in faces for i in range(1,len(face)-1)]
    triangles = el(data,'triangles',{'count':str(len(tris)),'material':'paint'})
    el(triangles,'input',{'semantic':'VERTEX','source':'#'+ident+'-verts','offset':'0'})
    el(triangles,'p',text=' '.join(str(n) for tri in tris for n in tri))
    node = el(parent,'node',{'id':ident+'-node','name':name})
    instance = el(node,'instance_geometry',{'url':'#'+ident})
    el(el(el(instance,'bind_material'),'technique_common'),'instance_material',{'symbol':'paint','target':'#'+material})

def box(name, x,y,z,w,d,h,parent=machine,material='yellow'):
    primitives.append({'type':'box','name':name,'origin':[x,y,z],'size':[w,d,h],'material':material,'group':'Machine' if parent is machine else 'Clearances' if parent is gaps else 'Service'})
    v=[(x,y,z),(x+w,y,z),(x+w,y+d,z),(x,y+d,z),(x,y,z+h),(x+w,y,z+h),(x+w,y+d,z+h),(x,y+d,z+h)]
    mesh(name,v,[(3,2,1,0),(0,1,5,4),(1,2,6,5),(2,3,7,6),(3,0,4,7),(4,5,6,7)],parent,material)

def cylinder(name,cx,cz,r,y0,y1,material='yellow',parent=machine):
    primitives.append({'type':'cylinder','name':name,'center':[cx,y0,cz],'radius':r,'depth':y1-y0,'material':material,'group':'Machine'})
    n=48
    v=[(cx+r*math.cos(i*2*math.pi/n),y,cz+r*math.sin(i*2*math.pi/n)) for y in (y0,y1) for i in range(n)]
    faces=[tuple(range(n)),tuple(range(2*n-1,n-1,-1))]
    faces += [(i,n+i,n+(i+1)%n,(i+1)%n) for i in range(n)]
    mesh(name,v,faces,parent,material)

def ring(name,cx,cz,outer,inner,y0,y1,material='yellow',parent=machine):
    primitives.append({'type':'ring','name':name,'center':[cx,y0,cz],'outer':outer,'inner':inner,'depth':y1-y0,'material':material,'group':'Machine'})
    n=48
    v=[(cx+r*math.cos(i*2*math.pi/n),y,cz+r*math.sin(i*2*math.pi/n)) for r,y in ((outer,y0),(outer,y1),(inner,y1),(inner,y0)) for i in range(n)]
    # Outward winding: theta tangent crossed with +Y points inward.
    faces=[(((j+1)%4)*n+i,((j+1)%4)*n+(i+1)%n,j*n+(i+1)%n,j*n+i) for j in range(4) for i in range(n)]
    mesh(name,v,faces,parent,material)


exec(compile(Path(__file__).with_name('layout.py').read_text(), str(Path(__file__).with_name('layout.py')), 'exec'))
# Geometry-only mode for the common generation CLI.
import os, sys
if os.environ.get('SKETCHUP_ARTIFACT_SKIP_RENDER') == '1':
    sys.exit(0)

# Render the actual mesh with a small orthographic renderer using only Python's standard library.
import struct, zlib, sys
OPEN_VIEW = '--open' in sys.argv
if OPEN_VIEW:
    hinge_z = 2579
    records = [(name, [(x,z-hinge_z,hinge_z-y) for x,y,z in vertices] if name.startswith('Верхний шкаф —') else vertices, faces, material, is_body) for name,vertices,faces,material,is_body in records]
W,H=1400,1800
if os.environ.get('SKETCHUP_ARTIFACT_RENDER_QUALITY', 'high') == 'high':
    sys.path.insert(0, str(Path(__file__).resolve().parents[2] / 'scripts'))
    from render_quality import render_preview
    render_preview(globals())
    sys.exit(0)

pixels=bytearray([246,245,240])*(W*H)
depth=[-float('inf')]*(W*H)
u=(0.866,0.5,0)
v=(-0.25,0.433,0.866)
camera=(0.433,-0.75,0.5)
def dot(a,b): return sum(x*y for x,y in zip(a,b))
all_points=[p for _,vertices,_,_,_ in records for p in vertices]
u_min,u_max=min(dot(p,u) for p in all_points),max(dot(p,u) for p in all_points)
v_min,v_max=min(dot(p,v) for p in all_points),max(dot(p,v) for p in all_points)
scale=min((W-160)/(u_max-u_min),(H-150)/(v_max-v_min))
def project(p):
    return (W/2+(dot(p,u)-(u_min+u_max)/2)*scale,H/2-(dot(p,v)-(v_min+v_max)/2)*scale,dot(p,camera))
light=(0.3,-0.6,0.74)
ordered = [r for r in records if r[3]!='red'] + sorted([r for r in records if r[3]=='red'],key=lambda r:sum(dot(p,camera) for p in r[1])/len(r[1]))
for name,vertices,faces,material,_ in ordered:
    coords=[project(p) for p in vertices]
    for face in faces:
        a,b,c=[vertices[i] for i in face[:3]]
        ab=[b[i]-a[i] for i in range(3)]; ac=[c[i]-a[i] for i in range(3)]
        normal=(ab[1]*ac[2]-ab[2]*ac[1],ab[2]*ac[0]-ab[0]*ac[2],ab[0]*ac[1]-ab[1]*ac[0])
        norm=math.sqrt(dot(normal,normal))
        brightness=0.72+0.28*abs(dot(normal,light)/norm) if norm else 1
        color=bytes(int(min(255,component*brightness)) for component in COLORS[material])
        for k in range(1,len(face)-1):
            A,B,C=[coords[i] for i in (face[0],face[k],face[k+1])]
            determinant=(B[1]-C[1])*(A[0]-C[0])+(C[0]-B[0])*(A[1]-C[1])
            if abs(determinant)<1e-8: continue
            for py in range(max(0,int(min(A[1],B[1],C[1]))),min(H,int(max(A[1],B[1],C[1]))+1)):
                for px in range(max(0,int(min(A[0],B[0],C[0]))),min(W,int(max(A[0],B[0],C[0]))+1)):
                    l1=((B[1]-C[1])*(px-C[0])+(C[0]-B[0])*(py-C[1]))/determinant
                    l2=((C[1]-A[1])*(px-C[0])+(A[0]-C[0])*(py-C[1]))/determinant
                    l3=1-l1-l2
                    if min(l1,l2,l3)<-1e-8: continue
                    if material == 'red' and k>1 and l3<1e-8: continue
                    z=l1*A[2]+l2*B[2]+l3*C[2]; index=py*W+px
                    if z>depth[index]+(1e-5 if material == 'red' else 0):
                        if material == 'red':
                            pixels[index*3:index*3+3]=bytes(round(pixels[index*3+j]*0.82+color[j]*0.18) for j in range(3))
                        else:
                            depth[index]=z; pixels[index*3:index*3+3]=color
def chunk(tag,data): return struct.pack('!I',len(data))+tag+data+struct.pack('!I',zlib.crc32(tag+data)&0xffffffff)
raw=b''.join(b'\0'+pixels[y*W*3:(y+1)*W*3] for y in range(H))
png=b'\x89PNG\r\n\x1a\n'+chunk(b'IHDR',struct.pack('!2I5B',W,H,8,2,0,0,0))+chunk(b'IDAT',zlib.compress(raw))+chunk(b'IEND',b'')
(OUTPUT_DIR / ('preview-open.png' if OPEN_VIEW else 'preview.png')).write_bytes(png)
print('Rendered actual DAE geometry to preview.png')

import base64
encoded=base64.b64encode(png).decode('ascii')
svg=f'''<svg xmlns="http://www.w3.org/2000/svg" width="2200" height="2100" viewBox="0 0 2200 2100">
<rect width="2200" height="2100" fill="#f6f5f0"/>
<g font-family="Arial, sans-serif" fill="#252b26">
<text x="90" y="75" font-size="40" font-weight="bold">Пустая стойка / верхний шкаф открывается вверх</text>
<text x="90" y="122" font-size="25">Корпус 676 × 720 × 2600 мм · рамка 150 мм · потолок 2750 мм</text>
<image x="500" y="150" width="1400" height="1800" href="data:image/png;base64,{encoded}"/>
<text x="90" y="1980" font-size="25">Жёлтый — детали сборки. Красный — плоские зоны свободного места.</text>
<text x="90" y="2025" font-size="22" fill="#666b61">Ручки выступают на 12 мм. Опорные полки, крепёж и монтажная рамка показаны эскизно.</text>
<text x="90" y="2065" font-size="22" fill="#666b61">Задняя часть открыта для доступа к подключениям. Фасад верхнего шкафа показан закрытым.</text>
</g>'''

def label(title,subtitle,location,y,right=False):
    px,py,_=project(location); px+=500; py+=150
    x=2110 if right else 90
    elbow=1900 if right else 480
    align='end' if right else 'start'
    return f'''<g font-family="Arial, sans-serif" fill="#30372e">
<path d="M {px:.1f},{py:.1f} L {elbow},{y+15} L {x},{y+15}" fill="none" stroke="#737c6d" stroke-width="2"/>
<circle cx="{px:.1f}" cy="{py:.1f}" r="5" fill="#737c6d"/>
<text x="{x}" y="{y-20}" font-size="28" text-anchor="{align}" font-weight="bold">{title}</text>
<text x="{x}" y="{y+10}" font-size="22" text-anchor="{align}">{subtitle}</text></g>'''

svg+=label('Рамка под натяжной','2600–2750 мм · высота 150 мм',[640,0,2700],275,True)
svg+=label('Верхний шкаф','на всю высоту до 2600 мм · стенки 18 мм',[-20,0,2370],530)
svg+=label('Подъёмный фасад','открывается вверх · высота 650 мм',[-17,0,2050],790)
svg+=label('Пустой верхний отсек','1038–1908 мм · просвет 870 мм', [0,28,1475],1060)
svg+=label('Отдельная полка','толщина 18 мм · верх 1038 мм',[620,0,1029],1210,True)
svg+=label('Пустой нижний отсек','150–1020 мм · просвет 870 мм',[0,28,575],1530)
svg+=label('Основание с ящиком','верх полки 150 мм',[-17,0,75],1850)
svg+='</svg>'
if not OPEN_VIEW:
    (OUTPUT_DIR / ('preview-annotated.svg')).write_text(svg,encoding='utf-8')
print('Wrote annotated tower preview')
