"""Parametric sketch: tower body 2600 mm, ceiling frame 150 mm."""
import copy
import json

BODY_HEIGHT = 2600
CEILING_HEIGHT = 2750
BASE_TOP = 150
DRYER_BOTTOM = 1038
DRAWER_BOTTOM = 1926
GROUP_NAMES = {
    'Frame': 'Корпус стойки — 2600 мм',
    'BaseDrawer': 'Нижний ящик в основании 150 мм',
    'UpperDoor': 'Верхний шкаф — фасад открывается вверх',
    'CeilingFrame': 'Монтажная рамка под натяжной потолок — 150 мм',
    'Zones': 'Монтажные зазоры — красные плоскости',
    'Access': 'Зона доступа и выдвижения — красная плоскость',
}
nodes = {'Frame': machine}
machine.set('name', GROUP_NAMES['Frame'])
gaps.set('name', GROUP_NAMES['Zones'])
access.set('name', GROUP_NAMES['Access'])
nodes.update({'Zones': gaps, 'Access': access})
for key, name in GROUP_NAMES.items():
    if key not in nodes:
        nodes[key] = el(assembly, 'node', {'id': key, 'name': name})

def emit(shape):
    parent = nodes[shape['group']]
    kind = shape['type']
    if kind == 'box':
        box(shape['name'], *shape['origin'], *shape['size'], parent, shape['material'])
    elif kind == 'cylinder':
        x, y, z = shape['center']
        cylinder(shape['name'], x, z, shape['radius'], y, y+shape['depth'], shape['material'], parent)
    elif kind == 'ring':
        x, y, z = shape['center']
        ring(shape['name'], x, z, shape['outer'], shape['inner'], y, y+shape['depth'], shape['material'], parent)
    elif kind == 'rectangle':
        mesh(shape['name'], shape['vertices'], [(0,1,2,3)], parent, shape['material'])
        primitives.append(shape)
    primitives[-1]['group'] = shape['group']

def part(name, origin, size, group='Frame', material='yellow'):
    emit({'type':'box','name':name,'origin':origin,'size':size,'group':group,'material':material})

# Clear opening 640 mm; 18 mm carcass panels; rear service space remains open.
part('Левая боковина', [-38,0,0], [18,720,BODY_HEIGHT])
part('Правая боковина', [620,0,0], [18,720,BODY_HEIGHT])
part('Нижняя панель основания', [-20,0,0], [640,720,18])
part('Полка под стиральной машиной — верх 150 мм', [-20,0,132], [640,720,18])
part('Полка второго отсека — верх 1038 мм', [-20,0,1020], [640,720,18])
part('Дно верхнего шкафа', [-20,0,1908], [640,720,18])
part('Задняя стенка верхнего шкафа', [-20,702,1926], [640,18,656])
part('Верх корпуса — отметка 2600 мм', [-20,0,2582], [640,720,18])
for z in (18,990,1880):
    part('Задняя поперечина — открытый доступ к коммуникациям', [-20,700,z], [640,18,50])

def drawer(group, bottom, top, label):
    # Minimal box, closed position. Guides and bearing design are not specified.
    part(label+' — фасад', [-17,0,bottom+3], [634,18,top-bottom-6], group)
    part(label+' — дно', [0,20,bottom+8], [600,620,12], group)
    for x in (0,588):
        part(label+' — стенка', [x,20,bottom+20], [12,620,top-bottom-32], group)
    part(label+' — задняя стенка', [12,628,bottom+20], [576,12,top-bottom-32], group)
    part(label+' — ручка', [215,-12,(bottom+top)/2-6], [170,12,12], group, 'ochre')
    for z in (bottom+3,top-4):
        part(label+' — шов фасада', [-17,-0.5,z], [634,0.5,1], group, 'ochre')
    for x in (-17,616):
        part(label+' — шов фасада', [x,-0.5,bottom+3], [1,0.5,top-bottom-6], group, 'ochre')

drawer('BaseDrawer',18,132,'Нижний ящик')
part('Верхний шкаф — фасад', [-17,0,1929], [634,18,650], 'UpperDoor')
part('Верхний шкаф — ручка', [215,-12,1960], [170,12,12], 'UpperDoor', 'ochre')
for z in (1929,2578):
    part('Верхний шкаф — шов фасада', [-17,-0.5,z], [634,0.5,1], 'UpperDoor', 'ochre')
for x in (-17,616):
    part('Верхний шкаф — шов фасада', [x,-0.5,1929], [1,0.5,650], 'UpperDoor', 'ochre')
for x in (65,495):
    part('Условная верхняя петля', [x,18,2560], [40,20,20], material='ochre')

# Rectangle-section frame is separate from the furniture body.
for z in (2600,2720):
    for y in (0,690):
        part('Рамка — горизонтальная планка', [-38,y,z], [676,30,30], 'CeilingFrame')
    for x in (-38,608):
        part('Рамка — боковая планка', [x,30,z], [30,660,30], 'CeilingFrame')
for x in (-38,608):
    for y in (0,690):
        part('Рамка — вертикальная стойка', [x,y,2630], [30,30,90], 'CeilingFrame')

def plane(name, vertices, group='Zones'):
    emit({'type':'rectangle','name':name,'vertices':vertices,'group':group,'material':'red'})

# Display planes are offset 0.5 mm into free space to avoid coplanar
# overlap with carcass panels. Nominal clearance dimensions stay unchanged.
plane('Сзади 100 мм — граница подключений', [[-19.5,699.5,150],[619.5,699.5,150],[619.5,699.5,1888],[-19.5,699.5,1888]])
plane('Слева 20 мм — граница зазора', [[-19.5,0,150],[-19.5,600,150],[-19.5,600,1888],[-19.5,0,1888]])
plane('Справа 20 мм — граница зазора', [[619.5,0,150],[619.5,600,150],[619.5,600,1888],[619.5,0,1888]])
plane('Над стиралкой 20 мм', [[0,0,1019.5],[600,0,1019.5],[600,600,1019.5],[0,600,1019.5]])
plane('Над сушилкой 20 мм', [[0,0,1907.5],[600,0,1907.5],[600,600,1907.5],[0,600,1907.5]])
plane('Спереди 650 мм — проекция открытого верхнего фасада', [[-38,-650,0],[638,-650,0],[638,0,0],[-38,0,0]], 'Access')

# Empty furniture only; preserve two 870 mm clear niches for 850 mm appliances.
assert not any(shape['group'] in ('Washer','Dryer') for shape in primitives)
assert 620-(-20)==640
assert 1020-150==870 and 1908-1038==870
assert 2582-1926==656
assert 2750-2600==150

el(el(root,'scene'),'instance_visual_scene',{'url':'#Scene'})
E.indent(root)
path=(OUTPUT_DIR / ('laundry-tower-yellow.dae'))
E.ElementTree(root).write(path,encoding='utf-8',xml_declaration=True)
E.parse(path)
(OUTPUT_DIR / ('model-primitives.json')).write_text(json.dumps({
    'materials':COLORS,'shapes':primitives,'groups':GROUP_NAMES,'zone_opacity':0.18,
    'body_dimensions_mm':[676,720,BODY_HEIGHT],'panel_thickness_mm':18,'frame_height_mm':150,
    'total_height_mm':2750,'zone_display_offset_mm':0.5,
    'motions':{'UpperDoor':{'rotation_axis':[1,0,0],'rotation_degrees':-90},'BaseDrawer':{'translation_mm':[0,-400,0]}},'front_handle_projection_mm':12,
    'upper_cabinet_clear_height_mm':656,'upper_door_hinge_mm':[-17,0,2579],
},ensure_ascii=False,indent=2),encoding='utf-8')

# Also export only the furniture and ceiling frame, for use with existing appliances.
frame_root=copy.deepcopy(root)
fscene=frame_root.find('.//{'+NS+'}visual_scene')
fassembly=fscene.find('{'+NS+'}node')
for child in list(fassembly):
    if child.get('id') in ('Washer','Dryer'):
        fassembly.remove(child)
used={item.get('url')[1:] for item in frame_root.findall('.//{'+NS+'}instance_geometry')}
library=frame_root.find('{'+NS+'}library_geometries')
for geometry in list(library):
    if geometry.get('id') not in used:
        library.remove(geometry)
E.ElementTree(frame_root).write((OUTPUT_DIR / ('cabinet-only-yellow.dae')),encoding='utf-8',xml_declaration=True)
print(f'Tower exported: empty carcass 676×720×2600; panels 18 mm; ceiling frame 150; total 2750 mm; {len(primitives)} shapes')
