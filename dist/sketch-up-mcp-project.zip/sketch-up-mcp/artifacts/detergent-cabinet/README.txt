Генерируемые DAE, JSON, PNG, SVG и SKP сохраняются в подпапку cache/.
Перед сборкой через MCP выполни python3 scripts/generate_artifacts.py --geometry-only из корня проекта.
Папка cache/ не входит в Git и пересоздаётся генератором.

Отдельный шкаф для средств: 300 × 720 × 2600 мм, рамка до потолка 2750 мм.

Компоновка снизу вверх:
— Закрытый нижний отсек: полка на 780–798 мм.
— Нижний ящик: дно 830–846 мм; место над дном 364 мм.
— Средний ящик: дно 1210–1226 мм; место над дном 364 мм.
— Верхний неглубокий ящик: дно 1590–1606 мм; место над дном 194 мм.
— Верхний шкаф: дно 1800–1818 мм, полка 2180–2198 мм, верх 2582–2600 мм.
— Отдельная рамка: 2600–2750 мм.

Корпус 18 мм. Ширина между стенками 264 мм.
Дно METABOX: 233 × 548 × 16 мм; условная номинальная длина 550 мм.
Планировочная формула Blum: ширина дна = внутренний проём − 31 мм.
https://publications.blum.com/2026/catalogue/en/351/
Точная форма профилей, крепёж и ход зависят от выбранного артикула; здесь они эскизные.
Варианты показывают ход 400 мм; это не заявление о полном выдвижении выбранного комплекта.
Жёлтый корпус и оттенки жёлтого на движущихся ящиках; серые неподвижные направляющие.
Красный: одна прозрачная плоскость доступа 600 мм, без толщины и рамок.

Превью:
preview-closed.png — закрытый шкаф.
preview-lower-open.png — нижний рабочий ящик открыт.
preview-all-open.png — все три ящика открыты.
preview-mechanism.png — боковина снята, ящики выдвинуты на 400/250/100 мм.

Импорт без скрипта: File → Import → COLLADA (*.dae).
detergent-closed.dae / detergent-lower-open.dae / detergent-all-open.dae / detergent-mechanism.dae.
DAE содержит группы деталей, но не вкладки сцен SketchUp.

Повторная генерация:
python3 artifacts/detergent-cabinet/build_model.py closed
python3 artifacts/detergent-cabinet/build_model.py lower-open
python3 artifacts/detergent-cabinet/build_model.py all-open
python3 artifacts/detergent-cabinet/build_model.py mechanism

Создание в SketchUp выполняется через MCP build_assembly из artifacts/detergent-cabinet/cache/model-primitives.json.
Сначала из корня основного проекта: python3 scripts/generate_artifacts.py detergent-cabinet --geometry-only.
Для обновления используй стабильный key, replace:true и новый operation_id.
Для вариантов дверей/ящиков используй transform_object или create_scene_variants;
для сохранения — save_model или export_component.
