"""Planning model; metal profiles are schematic, not hardware manufacturing drawings."""
import json

VARIANTS = {
    'closed': {'name':'01 — Закрыт', 'travel':[0,0,0], 'cutaway':False},
    'lower-open': {'name':'02 — Нижний ящик открыт', 'travel':[400,0,0], 'cutaway':False},
    'all-open': {'name':'03 — Все ящики открыты', 'travel':[400,400,400], 'cutaway':False},
    'mechanism': {'name':'04 — Метабоксы и направляющие', 'travel':[400,250,100], 'cutaway':True},
}
assert VARIANT in VARIANTS, VARIANT
GROUP_NAMES = {'Frame':'Корпус 2600 мм — панели 18 мм', 'CeilingFrame':'Рамка под потолок — 150 мм', 'LowerDoor':'Нижний отсек — фасад', 'UpperDoor':'Верхний отсек — фасад', 'RightSide':'Правая боковина — снять для осмотра',
               'Guides':'Неподвижные направляющие — условный профиль',
               'Drawer1':'01 — Нижний METABOX / бутылки',
               'Drawer2':'02 — Средний METABOX / бутылки',
               'Drawer3':'03 — Верхний METABOX / мелочи',
               'Access':'Выдвижение и доступ — красная плоскость'}
assembly.remove(gaps)
machine.set('name', GROUP_NAMES['Frame'])
access.set('name', GROUP_NAMES['Access'])
nodes = {'Frame':machine, 'Access':access}
for key, name in GROUP_NAMES.items():
    if key not in nodes:
        nodes[key] = el(assembly,'node',{'id':key,'name':name})

def part(name, origin, size, group='Frame', material='yellow'):
    if VARIANTS[VARIANT]['cutaway'] and group=='RightSide':
        return
    position=list(origin)
    if group.startswith('Drawer'):
        position[1] -= VARIANTS[VARIANT]['travel'][int(group[-1])-1]
    box(name,*position,*size,nodes[group],material)
    # The JSON always describes the closed assembly for native editable SketchUp.
    primitives[-1].update(origin=list(origin),group=group)

part('Левая боковина 18 мм',[0,0,0],[18,720,2600])
part('Правая боковина 18 мм',[282,0,0],[18,720,2600],'RightSide')
part('Нижняя панель 18 мм',[18,0,0],[264,720,18])
part('Верхняя панель 18 мм',[18,0,2582],[264,720,18])
part('Задняя стенка 18 мм',[18,702,18],[264,18,2564])

part('Полка над нижним отсеком',[18,0,780],[264,702,18])
part('Дно верхнего отсека',[18,0,1800],[264,702,18])
part('Полка верхнего отсека',[18,18,2180],[264,684,18])
for group,lo,hi in [('LowerDoor',21,777),('UpperDoor',1821,2579)]:
    part(GROUP_NAMES[group]+' — панель',[3,0,lo],[294,18,hi-lo],group)
    part(GROUP_NAMES[group]+' — ручка',[252,-12,lo+80],[12,12,110],group,'ochre')
for z in (2600,2720):
    for y in (0,690):
        part('Рамка — передняя/задняя планка',[0,y,z],[300,30,30],'CeilingFrame')
    for x in (0,270):
        part('Рамка — боковая планка',[x,30,z],[30,660,30],'CeilingFrame')
for x in (0,270):
    for y in (0,690):
        part('Рамка — стойка',[x,y,2630],[30,30,90],'CeilingFrame')

DRAWERS=[]
for index,(bottom,front_lo,front_hi,side_height) in enumerate(
        [(830,801,1178,153),(1210,1180,1558,153),(1590,1560,1797,89)],1):
    group='Drawer'+str(index)
    label=GROUP_NAMES[group]
    part(label+' — фасад 18 мм',[3,0,front_lo],[294,18,front_hi-front_lo],group)
    part(label+' — ручка',[95,-12,front_hi-42],[110,12,12],group,'ochre')
    part(label+' — дно 16 мм / ширина 233 мм',[33.5,36,bottom],[233,548,16],group,'highlight')
    part(label+' — задняя стенка 16 мм',[33.5,568,bottom+16],[233,16,side_height-16],group,'highlight')
    for side,x in [('левая',29.5),('правая',266.5)]:
        part(label+' — '+side+' металлическая боковина',[x,36,bottom],[4,550,side_height],group,'highlight')
        part(label+' — '+side+' верхняя кромка профиля',[x-1,36,bottom+side_height-3],[6,550,3],group,'ochre')
        part(label+' — '+side+' подвижный профиль',[x,36,bottom-8],[4,550,8],group,'ochre')
        part(label+' — '+side+' крепление фасада',[x,18,bottom+18],[4,18,42],group,'ochre')
    for side,x in [('левая',18),('правая',272)]:
        part(label+' — '+side+' корпусная направляющая',[x,36,bottom-10],[10,550,16],'Guides','metal')
        for y in (60,260,510):
            part(label+' — '+side+' крепёж направляющей',[x+2,y,bottom-5],[6,5,5],'Guides','ochre')
    DRAWERS.append({'group':group,'anchor_mm':[3,0,front_lo],'bottom_mm':bottom,
                    'side_height_mm':side_height,'bottom_width_mm':233,
                    'bottom_depth_mm':548,'nominal_length_mm':550,
                    'clear_storage_height_mm':[364,364,194][index-1]})

vertices=[[0,-600,0],[300,-600,0],[300,0,0],[0,0,0]]
mesh('Зона доступа 600 мм — одна плоскость',vertices,[(0,1,2,3)],access,'red')
primitives.append({'type':'rectangle','name':'Зона доступа 600 мм — одна плоскость',
                   'vertices':vertices,'group':'Access','material':'red'})
el(el(root,'scene'),'instance_visual_scene',{'url':'#Scene'})
E.indent(root)
E.ElementTree(root).write((OUTPUT_DIR / ('detergent-'+VARIANT+'.dae')),encoding='utf-8',xml_declaration=True)
if VARIANT=='closed':
    (OUTPUT_DIR / ('model-primitives.json')).write_text(json.dumps({
        'materials':COLORS,'shapes':primitives,'groups':GROUP_NAMES,'zone_opacity':0.18,
        'body_dimensions_mm':[300,720,2600],'panel_thickness_mm':18,'frame_height_mm':150,'total_height_mm':2750,
        'doors':[{'group':'LowerDoor','hinge_mm':[3,0,21],'angle_degrees':-100},{'group':'UpperDoor','hinge_mm':[3,0,1821],'angle_degrees':-100}],
        'clear_case_width_mm':264,'drawer_bottom_width_mm':233,'drawers':DRAWERS,
        'variants':VARIANTS,'hardware_note':'Условные профили METABOX. NL 550; выдвижение 400 мм в эскизе. Артикул и реальный ход не выбраны.',
        'reference':'https://publications.blum.com/2026/catalogue/en/351/',
    },ensure_ascii=False,indent=2),encoding='utf-8')
print('Exported',VARIANT,'300×720×2600 + ceiling frame 150 mm; drawer bottom 233×548 mm')
